#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

int main()
{
    int i, j;
    int arr[31] = { 0 };
    int num;

    for (i = 0; i < 28; i++)
    {
        scanf("%d", &num);
        arr[num] = num;
    }
    for (i = 1; i < 31; i++)
    {
        if (arr[i] == 0)
        {
            printf("%d \n", i);
        }
    }

    return 0;
}
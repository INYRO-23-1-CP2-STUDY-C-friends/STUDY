#include<stdio.h>

int main(void)
{
	int i, n;
	printf("���� �Է� : ");
	scanf_s("%d", &n);

	for (i = 2; i <= n; i++)
	{
		if (n % i == 0)
		{
			printf("%d", i);
			n = n / i;
			if (n % i == 0)
			printf("*");

			else
			{
				if (n > i)
					printf("*");
			}
			i = 1;
		}
	}
	return 0;
}
#include<stdio.h>
#include<string.h>

int main(void)
{
	int i, j;

	for (i = 65; i <= 90; i++)
	{
		printf("%c%c", i, i + 32);
		printf(" ");
	}


	return 0;
}
#include<stdio.h>

int main(void)
{
	int a[][5] = { {1, 2, 3, 4, 5},
				  {6, 7, 8, 9, 10},
				  {11, 12, 13, 14, 15},
				  {16,17,18,19,20},
				  {21,22,23,24,25} };
	int i, j;
	int row[5] = { };
	int column[5] = { };
	int total = 0;
	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 5; j++)
		{
			row[i] = row[i] + a[i][j];
			column[i] = column[i] + a[j][i];
		}
	}

	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 5; j++)
		{
			printf("%1.2f ", (float)(a[i][j]));
		}
			printf("%1.2f %1.2f", (float)(row[i]), (float)(row[i]/5));
		
		printf("\n");
	}
	for (i = 0; i < 5; i++)
	{
		printf("%1.2f ", (float)(column[i]));
	}
	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 5; j++)
			total = total + a[i][j];
	}

	printf("%1.2f", (float)(total));
	printf("\n");
	for (i = 0; i < 5; i++)
	{
		printf("%1.2f ", (float)(column[i]/5));
	}
	printf("       %1.2f", (float)(total / 25));
	return 0;
}

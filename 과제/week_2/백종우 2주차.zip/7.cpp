#include<stdio.h>

int main(void)
{
	char s[] = "Test for #7 in CPL2 Mid-Exam.";
	int n[26] = { 0 };
	int i, c;

	for (i = 0; i < sizeof(s); i++)
	{
		if ((s[i] >= 'A' && s[i] <= 'Z' || s[i] >= 'a' && s[i] <= 'z'))
			if (s[i] <= 'Z')
				n[s[i] - 'A']++;
			else
				n[s[i] - 'a']++;
	}
	for (i = 0; i < 26; i++)
		if (n[i])
			printf("%c%c count: %d\n", i + 65, i + 97, n[i]);
	return 0;
}
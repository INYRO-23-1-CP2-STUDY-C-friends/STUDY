#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS

int main(void)
{
	int i, change, count[4];
	int coin[4] = { 500, 100 , 50, 10 };

	printf("�Ž����� �Է� : ");
	scanf_s("%d", &change);

	for (i = 0; i < 4; i++)
	{
		count[i] = change / coin[i];
		change = change % coin[i];
		if (change < 10)
			count[3]++;
		printf("%d���� = %d��\n", coin[i], count[i]);
	}

	return 0;
}
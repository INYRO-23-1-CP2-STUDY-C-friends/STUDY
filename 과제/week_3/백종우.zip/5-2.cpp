#include<stdio.h>

int gcdf(int n1, int n2)
{
	int i;
	int small = (n1 > n2) ? n2 : n1;
	int gcd;
	for (i = 1; i <= small; i++)
	{
		if (n1 % i == 0 && n2 % i == 0)
			gcd = i;
	}
	return gcd;
}

int main(void)
{
	int n1, n2;
	int gcd;
	printf("����1 �Է� : ");
	scanf_s("%d", &n1);
	printf("����2 �Է� : ");
	scanf_s("%d", &n2);

	gcd = gcdf(n1, n2);

	printf("�ִ����� : %d",gcd);

	return 0;
}
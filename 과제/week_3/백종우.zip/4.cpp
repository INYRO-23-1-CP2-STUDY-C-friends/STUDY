#include<stdio.h>

int main(void)
{
	char cin;
	printf("���� �Է� : ");
	scanf_s("%c", &cin, 1);

	if (cin >= 'a' && cin <= 'z')
		cin = cin - 32;
	else if (cin >= 'A' && cin <= 'Z')
		cin = cin + 32;

	printf("%c", cin);

	return 0;
}
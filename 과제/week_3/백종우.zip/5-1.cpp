#include<stdio.h>

int main(void)
{
	int i, j;
	int n1, n2;
	int gcd;
	printf("����1 �Է� : ");
	scanf_s("%d", &n1);
	printf("����2 �Է� : ");
	scanf_s("%d", &n2);

	for (i = 1; i <= n1 && i <= n2; ++i)
	{
		if (n1 % i == 0 && n2 % i == 0)
			gcd = i;
	}
	printf("%d", gcd);


	return 0;
}
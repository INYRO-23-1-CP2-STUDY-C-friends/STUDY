#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS

int main(void)
{
	int i, j, k, a;

	printf("���� �Է� :");
	scanf_s("%d", &a);

	for (i = 1; i < a+1; i++)
	{
		for (j = a; j > i; j--)
		{
			printf(" ");
		}
		for (k = 0; k < i; k++)
		{
			printf("*");
		}
		printf("\n");
	}


	return 0;
}